package rod_cutting;

public class PaperRollCuttingBottomUp {
	
	
	public static double bottom_up_rod_cut(double[] prices, int length) {
		double[] revenue = new double[length + 1];
		double q;
		
		if(prices.length == 0) {
			return 0;
		}
		
		for(int j = 1; j <= length; j++) {
			q = Integer.MIN_VALUE;
			if(j < prices.length+1) {
				q = prices[j-1];
			}
			for(int i = j - 1; i >= (length/j); i--) {
				q = Math.max(q, revenue[i - 1] + revenue[j - i - 1]);
			}
			revenue[j - 1] = q;
		}
		return revenue[length-1];
	}
	
	
	
	public static void main(String[] args) {
		double prices[] = { 1.2, 3, 5.8, 0,1000};
	
		System.out.println(bottom_up_rod_cut(prices, 15));
	}
	
	
	
}
